Front-end/Client-side app is powered by ReactJS!
